﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using ReolMarket.Core;
using ReolMarket.MVVM.Model;         // Booth, Customer
using ReolMarket.Data.Repository;    // BoothDbRepository, CustomerDbRepository

namespace ReolMarket.MVVM.ViewModel
{
    /// <summary>
    /// ViewModel for creating a lease (assigning a booth to a customer).
    /// This MVP version only prepares data; no save logic yet.
    /// </summary>
    internal class LeaseCreateViewModel : BaseViewModel
    {
        private readonly BoothDbRepository _boothRepo;
        private readonly CustomerDbRepository _customerRepo;

        private Booth? _selectedBooth;
        private Customer? _selectedCustomer;
        private DateTime _startDate = DateTime.Today;
        private decimal _monthlyPrice = 850m;
        private decimal _commissionPercent = 10m;

        /// <summary>
        /// List of available booths.
        /// </summary>
        public ObservableCollection<Booth> AvailableBooths { get; } = new();

        /// <summary>
        /// List of existing customers.
        /// </summary>
        public ObservableCollection<Customer> Customers { get; } = new();

        /// <summary>
        /// Selected booth.
        /// </summary>
        public Booth? SelectedBooth
        {
            get => _selectedBooth;
            set { if (SetProperty(ref _selectedBooth, value)) Validate(); }
        }

        /// <summary>
        /// Selected customer.
        /// </summary>
        public Customer? SelectedCustomer
        {
            get => _selectedCustomer;
            set { if (SetProperty(ref _selectedCustomer, value)) Validate(); }
        }

        /// <summary>
        /// Start date of lease.
        /// </summary>
        public DateTime StartDate
        {
            get => _startDate;
            set { if (SetProperty(ref _startDate, value)) Validate(); }
        }

        /// <summary>
        /// Monthly rent amount.
        /// </summary>
        public decimal MonthlyPrice
        {
            get => _monthlyPrice;
            set { if (SetProperty(ref _monthlyPrice, value)) Validate(); }
        }

        /// <summary>
        /// Commission percentage.
        /// </summary>
        public decimal CommissionPercent
        {
            get => _commissionPercent;
            set { if (SetProperty(ref _commissionPercent, value)) Validate(); }
        }

        /// <summary>
        /// Staff name performing the lease.
        /// </summary>
        public string StaffName { get; } = Environment.UserName;

        /// <summary>
        /// Command to save the lease.
        /// </summary>
        public ICommand SaveCommand { get; }

        /// <summary>
        /// Command to cancel lease creation.
        /// </summary>
        public ICommand CancelCommand { get; }

        /// <summary>
        /// Raised when dialog should be closed. True = saved, False = cancel.
        /// </summary>
        public event Action<bool>? RequestClose;

        public LeaseCreateViewModel()
        {
            Title = "Assign Booth to Customer";

            _boothRepo = new BoothDbRepository();
            _customerRepo = new CustomerDbRepository();

            SaveCommand = new RelayCommand(_ => ExecuteSave(), _ => CanSave());
            CancelCommand = new RelayCommand(_ => RequestClose?.Invoke(false));

            Load();
        }

        /// <summary>
        /// Loads customers and booths for selection.
        /// </summary>
        public void Load()
        {
            RunBusy(() =>
            {
                AvailableBooths.Clear();
                foreach (var b in _boothRepo.GetAll().OrderBy(b => b.BoothNumber))
                    AvailableBooths.Add(b);

                Customers.Clear();
                foreach (var c in _customerRepo.GetAll().OrderBy(c => c.CustomerName))
                    Customers.Add(c);

                Validate();
            }, "Loading lease data…");
        }

        /// <summary>
        /// Validates inputs.
        /// </summary>
        protected override void Validate()
        {
            ClearErrors(nameof(SelectedBooth));
            if (SelectedBooth == null)
                AddError(nameof(SelectedBooth), "Booth must be selected.");

            ClearErrors(nameof(SelectedCustomer));
            if (SelectedCustomer == null)
                AddError(nameof(SelectedCustomer), "Customer must be selected.");

            ClearErrors(nameof(StartDate));
            if (StartDate > DateTime.Today)
                AddError(nameof(StartDate), "Start date cannot be in the future.");

            ClearErrors(nameof(MonthlyPrice));
            if (MonthlyPrice < 0)
                AddError(nameof(MonthlyPrice), "Monthly price must be ≥ 0.");

            ClearErrors(nameof(CommissionPercent));
            if (CommissionPercent < 0 || CommissionPercent > 100)
                AddError(nameof(CommissionPercent), "Commission must be between 0 and 100.");

            (SaveCommand as RelayCommand)?.RaiseCanExecuteChanged();
        }

        private bool CanSave() => !IsBusy && !HasErrors;

        /// <summary>
        /// Executes the save (currently does nothing).
        /// </summary>
        private void ExecuteSave()
        {
            if (!CanSave()) return;

            // TODO: Add actual lease creation logic when lease model is ready.
            RequestClose?.Invoke(true);
        }
    }
}
