﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using ReolMarket.Core;
using ReolMarket.MVVM.Model;          // Booth, BoothStatus
using ReolMarket.Data.Repository;     // BoothDbRepository

namespace ReolMarket.MVVM.ViewModel
{
    /// <summary>
    /// Lists and manages booths (reoler) with simple in-memory filtering.
    /// Stays within current project scope: synchronous repositories, no lease flow.
    /// </summary>
    internal class BoothsViewModel : BaseViewModel
    {
        // Repository (sync)
        private readonly BoothDbRepository _boothRepo;

        // Backing fields
        private Booth? _selectedBooth;
        private string? _searchText;
        private bool _onlyFree;
        private BoothStatus? _statusFilter;

        // Cache of all booths (for client-side filtering)
        private Booth[] _allBooths = Array.Empty<Booth>();

        /// <summary>
        /// UI-bound collection of booths.
        /// </summary>
        public ObservableCollection<Booth> Booths { get; } = new();

        /// <summary>
        /// The booth currently selected in the UI list.
        /// </summary>
        public Booth? SelectedBooth
        {
            get => _selectedBooth;
            set
            {
                if (SetProperty(ref _selectedBooth, value))
                    RefreshCommands();
            }
        }

        /// <summary>
        /// Free-text filter (matches booth number).
        /// </summary>
        public string? SearchText
        {
            get => _searchText;
            set
            {
                if (SetProperty(ref _searchText, value))
                    ApplyFilters();
            }
        }

        /// <summary>
        /// If true, only shows booths with Status = Ledig.
        /// </summary>
        public bool OnlyFree
        {
            get => _onlyFree;
            set
            {
                if (SetProperty(ref _onlyFree, value))
                    ApplyFilters();
            }
        }

        /// <summary>
        /// Optional booth status filter (e.g., Ledig/Optaget).
        /// </summary>
        public BoothStatus? StatusFilter
        {
            get => _statusFilter;
            set
            {
                if (SetProperty(ref _statusFilter, value))
                    ApplyFilters();
            }
        }

        // Commands (note: RelayCommand(Action<object>, Predicate<object>))
        public ICommand RefreshCommand { get; }
        public ICommand AddBoothCommand { get; }
        public ICommand EditBoothCommand { get; }
        public ICommand DeleteBoothCommand { get; }

        /// <summary>
        /// Initializes the view model; wires up commands and loads initial data.
        /// </summary>
        public BoothsViewModel()
        {
            Title = "Booths";
            _boothRepo = new BoothDbRepository();

            RefreshCommand = new RelayCommand(_ => Load());
            AddBoothCommand = new RelayCommand(_ => AddBooth(), _ => !IsBusy);
            EditBoothCommand = new RelayCommand(_ => EditBooth(), _ => !IsBusy && SelectedBooth != null);
            DeleteBoothCommand = new RelayCommand(_ => DeleteBooth(), _ => !IsBusy && SelectedBooth != null);

            Load();
        }

        /// <summary>
        /// Loads all booths via repository, then applies current filters.
        /// </summary>
        private void Load()
        {
            RunBusy(() =>
            {
                _allBooths = _boothRepo.GetAll().ToArray();
                ApplyFilters();
            }, "Loading booths…");
        }

        /// <summary>
        /// Applies Search/Status/OnlyFree filters to the in-memory booth list.
        /// </summary>
        private void ApplyFilters()
        {
            var query = _allBooths.AsEnumerable();

            if (!string.IsNullOrWhiteSpace(SearchText))
            {
                var s = SearchText.Trim();
                query = query.Where(b => b.BoothNumber.ToString().Contains(s, StringComparison.OrdinalIgnoreCase));
            }

            if (StatusFilter.HasValue)
                query = query.Where(b => b.Status == StatusFilter.Value);

            if (OnlyFree)
                query = query.Where(b => b.Status == BoothStatus.Ledig);

            var result = query.OrderBy(b => b.BoothNumber).ToArray();

            Booths.Clear();
            foreach (var booth in result)
                Booths.Add(booth);
        }

        /// <summary>
        /// Creates a new booth with simple defaults (MVP).
        /// </summary>
        private void AddBooth()
        {
            RunBusy(() =>
            {
                var nextNo = _allBooths.Length == 0 ? 1 : _allBooths.Max(x => x.BoothNumber) + 1;
                var b = new Booth
                {
                    BoothID = Guid.NewGuid(),
                    BoothNumber = nextNo,
                    NumberOfShelves = 6,
                    HasHangerBar = false,
                    IsRented = false,
                    Status = BoothStatus.Ledig,
                    CustomerID = null
                };
                _boothRepo.Add(b);
                Load();
            }, "Adding booth…");
        }

        /// <summary>
        /// Example edit: toggles hanger bar and persists.
        /// </summary>
        private void EditBooth()
        {
            if (SelectedBooth == null) return;

            RunBusy(() =>
            {
                SelectedBooth.HasHangerBar = !SelectedBooth.HasHangerBar;
                _boothRepo.Update(SelectedBooth);
                Load();
            }, "Saving booth…");
        }

        /// <summary>
        /// Deletes the selected booth.
        /// </summary>
        private void DeleteBooth()
        {
            if (SelectedBooth == null) return;

            RunBusy(() =>
            {
                _boothRepo.Delete(SelectedBooth.BoothID);
                Load();
            }, "Deleting booth…");
        }

        /// <summary>
        /// Re-evaluates command CanExecute states.
        /// </summary>
        private void RefreshCommands()
        {
            (AddBoothCommand as RelayCommand)?.RaiseCanExecuteChanged();
            (EditBoothCommand as RelayCommand)?.RaiseCanExecuteChanged();
            (DeleteBoothCommand as RelayCommand)?.RaiseCanExecuteChanged();
        }
    }
}
