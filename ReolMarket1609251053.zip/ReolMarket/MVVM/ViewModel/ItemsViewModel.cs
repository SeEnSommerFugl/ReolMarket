﻿using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows.Input;
using ReolMarket.Core;
using ReolMarket.MVVM.Model;          // Item, Booth
using ReolMarket.Data.Repository;     // ItemDbRepository, BoothDbRepository

namespace ReolMarket.MVVM.ViewModel
{
    /// <summary>
    /// Lists and manages items (varer) using synchronous repositories and current MVVM models.
    /// </summary>
    internal class ItemsViewModel : BaseViewModel
    {
        // Repositories (sync)
        private readonly ItemDbRepository _itemRepo;
        private readonly BoothDbRepository _boothRepo;

        // Backing fields
        private Item? _selectedItem;
        private string? _searchText;
        private Guid? _boothFilterId;

        // Cache
        private Item[] _allItems = Array.Empty<Item>();

        /// <summary>
        /// The collection bound to the UI list of items.
        /// </summary>
        public ObservableCollection<Item> Items { get; } = new();

        /// <summary>
        /// Optional collection of booths for a filter dropdown.
        /// </summary>
        public ObservableCollection<Booth> Booths { get; } = new();

        /// <summary>
        /// The currently selected item in the list.
        /// </summary>
        public Item? SelectedItem
        {
            get => _selectedItem;
            set
            {
                if (SetProperty(ref _selectedItem, value))
                    RefreshCommands();
            }
        }

        /// <summary>
        /// Free-text search across item name and booth number (via lookup).
        /// </summary>
        public string? SearchText
        {
            get => _searchText;
            set
            {
                if (SetProperty(ref _searchText, value))
                    ApplyFilters();
            }
        }

        /// <summary>
        /// Optional booth filter. When set, only items in the selected booth are shown.
        /// </summary>
        public Guid? BoothFilterId
        {
            get => _boothFilterId;
            set
            {
                if (SetProperty(ref _boothFilterId, value))
                    ApplyFilters();
            }
        }

        // Commands (RelayCommand takes Action<object>, Predicate<object>)
        public ICommand RefreshCommand { get; }
        public ICommand AddItemCommand { get; }
        public ICommand EditItemCommand { get; }
        public ICommand DeleteItemCommand { get; }

        /// <summary>
        /// Initializes the view model; loads data.
        /// </summary>
        public ItemsViewModel()
        {
            Title = "Items";
            _itemRepo = new ItemDbRepository();
            _boothRepo = new BoothDbRepository();

            RefreshCommand = new RelayCommand(_ => Load());
            AddItemCommand = new RelayCommand(_ => AddItem(), _ => !IsBusy);
            EditItemCommand = new RelayCommand(_ => EditItem(), _ => !IsBusy && SelectedItem != null);
            DeleteItemCommand = new RelayCommand(_ => DeleteItem(), _ => !IsBusy && SelectedItem != null);

            Load();
        }

        /// <summary>
        /// Loads items and booths from repositories; applies current filters.
        /// </summary>
        private void Load()
        {
            RunBusy(() =>
            {
                // Booths to support filter and booth number lookups
                Booths.Clear();
                foreach (var b in _boothRepo.GetAll().OrderBy(b => b.BoothNumber))
                    Booths.Add(b);

                _allItems = _itemRepo.GetAll().ToArray();
                ApplyFilters();
            }, "Loading items…");
        }

        /// <summary>
        /// Applies search and booth filter to the cached list and updates the UI collection.
        /// </summary>
        private void ApplyFilters()
        {
            var query = _allItems.AsEnumerable();

            if (!string.IsNullOrWhiteSpace(SearchText))
            {
                var s = SearchText.Trim();

                // Lookup booth number via repository for search convenience
                query = query.Where(i =>
                    (!string.IsNullOrWhiteSpace(i.ItemName) && i.ItemName.Contains(s, StringComparison.OrdinalIgnoreCase)) ||
                    (_boothRepo.GetById(i.BoothID)?.BoothNumber.ToString().Contains(s, StringComparison.OrdinalIgnoreCase) ?? false));
            }

            if (BoothFilterId.HasValue)
                query = query.Where(i => i.BoothID == BoothFilterId.Value);

            var result = query
                .OrderBy(i => _boothRepo.GetById(i.BoothID)?.BoothNumber ?? int.MaxValue)
                .ThenBy(i => i.ItemName, StringComparer.OrdinalIgnoreCase)
                .ToArray();

            Items.Clear();
            foreach (var it in result)
                Items.Add(it);
        }

        /// <summary>
        /// Adds a simple item for the first booth (MVP).
        /// </summary>
        private void AddItem()
        {
            RunBusy(() =>
            {
                var booth = Booths.FirstOrDefault();
                if (booth == null) return;

                var item = new Item
                {
                    ItemID = Guid.NewGuid(),
                    ItemName = "New item",
                    ItemPrice = 10m,
                    BoothID = booth.BoothID
                };
                _itemRepo.Add(item);
                Load();
            }, "Adding item…");
        }

        /// <summary>
        /// Edits the selected item (simple placeholder change).
        /// </summary>
        private void EditItem()
        {
            if (SelectedItem == null) return;

            RunBusy(() =>
            {
                SelectedItem.ItemName = (SelectedItem.ItemName ?? string.Empty).Trim() + " *";
                _itemRepo.Update(SelectedItem);
                Load();
            }, "Saving item…");
        }

        /// <summary>
        /// Deletes the selected item.
        /// </summary>
        private void DeleteItem()
        {
            if (SelectedItem == null) return;

            RunBusy(() =>
            {
                _itemRepo.Delete(SelectedItem.ItemID);
                Load();
            }, "Deleting item…");
        }

        /// <summary>
        /// Re-evaluates command CanExecute states.
        /// </summary>
        private void RefreshCommands()
        {
            (AddItemCommand as RelayCommand)?.RaiseCanExecuteChanged();
            (EditItemCommand as RelayCommand)?.RaiseCanExecuteChanged();
            (DeleteItemCommand as RelayCommand)?.RaiseCanExecuteChanged();
        }
    }
}
