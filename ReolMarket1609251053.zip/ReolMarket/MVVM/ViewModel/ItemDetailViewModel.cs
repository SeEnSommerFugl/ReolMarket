﻿using System;
using System.Linq;
using System.Collections.ObjectModel;
using System.Windows.Input;
using ReolMarket.Core;
using ReolMarket.MVVM.Model;          // Item, Booth
using ReolMarket.Data.Repository;     // ItemDbRepository, BoothDbRepository

namespace ReolMarket.MVVM.ViewModel
{
    /// <summary>
    /// ViewModel for creating or editing a single item (vare) within the current MVP scope.
    /// Uses synchronous repositories and existing MVVM models.
    /// </summary>
    internal class ItemDetailViewModel : BaseViewModel
    {
        // Repositories (sync)
        private readonly ItemDbRepository _itemRepo;
        private readonly BoothDbRepository _boothRepo;

        // Backing fields
        private Guid? _itemId;
        private string? _itemName;
        private decimal _itemPrice;
        private Guid? _boothId;

        /// <summary>
        /// All available booths to choose from.
        /// </summary>
        public ObservableCollection<Booth> Booths { get; } = new();

        /// <summary>
        /// The name of the item (required).
        /// </summary>
        public string? ItemName
        {
            get => _itemName;
            set { if (SetProperty(ref _itemName, value)) Validate(); }
        }

        /// <summary>
        /// The price of the item (must be ≥ 0).
        /// </summary>
        public decimal ItemPrice
        {
            get => _itemPrice;
            set { if (SetProperty(ref _itemPrice, value)) Validate(); }
        }

        /// <summary>
        /// The ID of the booth this item belongs to (required).
        /// </summary>
        public Guid? BoothID
        {
            get => _boothId;
            set { if (SetProperty(ref _boothId, value)) Validate(); }
        }

        /// <summary>
        /// Command to save the item (create or update).
        /// </summary>
        public ICommand SaveCommand { get; }

        /// <summary>
        /// Command to cancel editing (typically closes dialog or navigates back).
        /// </summary>
        public ICommand CancelCommand { get; }

        /// <summary>
        /// Event raised when the user saves or cancels (used by parent to close view).
        /// true = saved, false = cancelled.
        /// </summary>
        public event Action<bool>? RequestClose;

        /// <summary>
        /// Initializes the view model (parameterless; uses sync repositories).
        /// </summary>
        public ItemDetailViewModel()
        {
            Title = "Item details";
            _itemRepo = new ItemDbRepository();
            _boothRepo = new BoothDbRepository();

            SaveCommand = new RelayCommand(_ => ExecuteSave(), _ => CanSave());
            CancelCommand = new RelayCommand(_ => RequestClose?.Invoke(false));
        }

        /// <summary>
        /// Loads an existing item for editing, or prepares a blank one for creation.
        /// </summary>
        public void Load(Guid? itemId = null)
        {
            RunBusy(() =>
            {
                // Load booths for selection
                Booths.Clear();
                foreach (var booth in _boothRepo.GetAll().OrderBy(b => b.BoothNumber))
                    Booths.Add(booth);

                _itemId = itemId;

                if (itemId.HasValue)
                {
                    var item = _itemRepo.GetById(itemId.Value);
                    if (item != null)
                    {
                        ItemName = item.ItemName;
                        ItemPrice = item.ItemPrice;
                        BoothID = item.BoothID;
                    }
                }
                else
                {
                    // Defaults for new item
                    ItemName = string.Empty;
                    ItemPrice = 0m;
                    BoothID = Booths.FirstOrDefault()?.BoothID;
                }

                Validate();
            }, "Loading item…");
        }

        /// <summary>
        /// Validates input fields and updates HasErrors.
        /// </summary>
        protected override void Validate()
        {
            ClearErrors(nameof(ItemName));
            if (string.IsNullOrWhiteSpace(ItemName))
                AddError(nameof(ItemName), "Item name is required.");

            ClearErrors(nameof(ItemPrice));
            if (ItemPrice < 0)
                AddError(nameof(ItemPrice), "Price cannot be negative.");

            ClearErrors(nameof(BoothID));
            if (!BoothID.HasValue)
                AddError(nameof(BoothID), "Please select a booth.");

            (SaveCommand as RelayCommand)?.RaiseCanExecuteChanged();
        }

        /// <summary>
        /// Determines whether the SaveCommand can currently execute.
        /// </summary>
        private bool CanSave() => !IsBusy && !HasErrors;

        /// <summary>
        /// Saves the item (create or update) via repository.
        /// </summary>
        private void ExecuteSave()
        {
            if (!CanSave()) return;

            RunBusy(() =>
            {
                if (_itemId.HasValue)
                {
                    // Update existing item
                    var item = _itemRepo.GetById(_itemId.Value);
                    if (item != null)
                    {
                        item.ItemName = ItemName!.Trim();
                        item.ItemPrice = ItemPrice;
                        item.BoothID = BoothID!.Value;
                        _itemRepo.Update(item);
                    }
                }
                else
                {
                    // Insert new item
                    var newItem = new Item
                    {
                        ItemID = Guid.NewGuid(),
                        ItemName = ItemName!.Trim(),
                        ItemPrice = ItemPrice,
                        BoothID = BoothID!.Value
                    };
                    _itemRepo.Add(newItem);
                }

                RequestClose?.Invoke(true);
            }, "Saving item…");
        }
    }
}
