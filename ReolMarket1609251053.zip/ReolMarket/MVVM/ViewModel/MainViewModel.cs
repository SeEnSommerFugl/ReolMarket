﻿namespace ReolMarket.MVVM.ViewModel
{
    internal class MainViewModel
    {

    }
}
