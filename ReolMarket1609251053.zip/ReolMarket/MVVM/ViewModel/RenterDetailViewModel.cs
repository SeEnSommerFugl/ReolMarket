﻿using System;
using System.Text.RegularExpressions;
using System.Windows.Input;
using ReolMarket.Core;
using ReolMarket.MVVM.Model;
using ReolMarket.Data.Repository;

namespace ReolMarket.MVVM.ViewModel
{
    /// <summary>
    /// ViewModel for creating or editing a renter (customer).
    /// </summary>
    internal class RenterDetailViewModel : BaseViewModel
    {
        private readonly CustomerDbRepository _repo;
        private Guid? _id;

        private string? _name;
        private string? _email;
        private string? _phone;
        private string? _address;
        private int _postalCode;

        /// <summary>
        /// Raised when the user saves or cancels. true = saved, false = cancelled.
        /// </summary>
        public event Action<bool>? RequestClose;

        /// <summary>
        /// Name of the customer (required).
        /// </summary>
        public string? CustomerName
        {
            get => _name;
            set { if (SetProperty(ref _name, value)) Validate(); }
        }

        /// <summary>
        /// Email address (optional, but validated if present).
        /// </summary>
        public string? Email
        {
            get => _email;
            set { if (SetProperty(ref _email, value)) Validate(); }
        }

        /// <summary>
        /// Phone number (optional).
        /// </summary>
        public string? PhoneNumber
        {
            get => _phone;
            set => SetProperty(ref _phone, value);
        }

        /// <summary>
        /// Postal address (optional).
        /// </summary>
        public string? Address
        {
            get => _address;
            set => SetProperty(ref _address, value);
        }

        /// <summary>
        /// Postal code (validated if outside 1000–9999).
        /// </summary>
        public int PostalCode
        {
            get => _postalCode;
            set { if (SetProperty(ref _postalCode, value)) Validate(); }
        }

        public ICommand SaveCommand { get; }
        public ICommand CancelCommand { get; }

        public RenterDetailViewModel()
        {
            Title = "Customer Details";
            _repo = new CustomerDbRepository();

            SaveCommand = new RelayCommand(_ => ExecuteSave(), _ => CanSave());
            CancelCommand = new RelayCommand(_ => RequestClose?.Invoke(false));
        }

        /// <summary>
        /// Loads data for an existing customer or prepares blank for creation.
        /// </summary>
        public void Load(Guid? customerId = null)
        {
            _id = customerId;

            if (customerId.HasValue)
            {
                var c = _repo.GetById(customerId.Value);
                if (c != null)
                {
                    CustomerName = c.CustomerName;
                    Email = c.Email;
                    PhoneNumber = c.PhoneNumber;
                    Address = c.Address;
                    PostalCode = c.PostalCode;
                }
            }
            else
            {
                CustomerName = "";
                Email = "";
                PhoneNumber = "";
                Address = "";
                PostalCode = 1000;
            }

            Validate();
        }

        /// <summary>
        /// Validates all user inputs.
        /// </summary>
        protected override void Validate()
        {
            ClearErrors(nameof(CustomerName));
            if (string.IsNullOrWhiteSpace(CustomerName))
                AddError(nameof(CustomerName), "Name is required.");

            ClearErrors(nameof(Email));
            if (!string.IsNullOrWhiteSpace(Email) && !IsValidEmail(Email))
                AddError(nameof(Email), "Invalid email format.");

            ClearErrors(nameof(PostalCode));
            if (PostalCode < 1000 || PostalCode > 9999)
                AddError(nameof(PostalCode), "Postal code must be between 1000 and 9999.");

            (SaveCommand as RelayCommand)?.RaiseCanExecuteChanged();
        }

        private bool CanSave() => !IsBusy && !HasErrors;

        /// <summary>
        /// Saves the customer (create or update).
        /// </summary>
        private void ExecuteSave()
        {
            if (!CanSave()) return;

            RunBusy(() =>
            {
                if (_id.HasValue)
                {
                    var customer = _repo.GetById(_id.Value);
                    if (customer != null)
                    {
                        customer.CustomerName = CustomerName!.Trim();
                        customer.Email = Email?.Trim() ?? "";
                        customer.PhoneNumber = PhoneNumber?.Trim() ?? "";
                        customer.Address = Address?.Trim() ?? "";
                        customer.PostalCode = PostalCode;

                        _repo.Update(customer);
                    }
                }
                else
                {
                    var newCustomer = new Customer
                    {
                        CustomerID = Guid.NewGuid(),
                        CustomerName = CustomerName!.Trim(),
                        Email = Email?.Trim() ?? "",
                        PhoneNumber = PhoneNumber?.Trim() ?? "",
                        Address = Address?.Trim() ?? "",
                        PostalCode = PostalCode
                    };

                    _repo.Add(newCustomer);
                }

                RequestClose?.Invoke(true);
            }, "Saving customer…");
        }

        private bool IsValidEmail(string email)
        {
            return Regex.IsMatch(email,
                @"^[^@\s]+@[^@\s]+\.[^@\s]+$",
                RegexOptions.IgnoreCase);
        }
    }
}
