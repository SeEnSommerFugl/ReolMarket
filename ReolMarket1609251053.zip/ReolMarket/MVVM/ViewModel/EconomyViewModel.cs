﻿using System;
using System.Collections.ObjectModel;
using System.Windows.Input;
using ReolMarket.Core;

namespace ReolMarket.MVVM.ViewModel
{
    /// <summary>
    /// MVP-friendly economy/settlement view model that stays within current project scope.
    /// No external services or domain DTOs are required yet.
    /// </summary>
    internal class EconomyViewModel : BaseViewModel
    {
        private DateTime _periodStart = new(DateTime.Today.Year, DateTime.Today.Month, 1);
        private DateTime _periodEnd = DateTime.Today;

        /// <summary>
        /// The start date of the settlement period.
        /// </summary>
        public DateTime PeriodStart
        {
            get => _periodStart;
            set => SetProperty(ref _periodStart, value);
        }

        /// <summary>
        /// The end date of the settlement period.
        /// </summary>
        public DateTime PeriodEnd
        {
            get => _periodEnd;
            set => SetProperty(ref _periodEnd, value);
        }

        /// <summary>
        /// Settlement result lines (placeholder type for MVP).
        /// </summary>
        public ObservableCollection<SettlementLineVm> SettlementLines { get; } = new();

        /// <summary>
        /// Command to generate the settlement list for the selected period (clears for now).
        /// </summary>
        public ICommand GenerateCommand { get; }

        public EconomyViewModel()
        {
            Title = "Monthly Settlement";
            GenerateCommand = new RelayCommand(_ => ExecuteGenerate(), _ => !IsBusy);
        }

        /// <summary>
        /// Clears the current settlement lines. (Real calculation will be added when sales data exists.)
        /// </summary>
        private void ExecuteGenerate()
        {
            RunBusy(() =>
            {
                SettlementLines.Clear();
                // TODO (later): Compute lines from actual sales once a Sale model/repository exists.
            }, "Generating settlement…");
        }
    }

    /// <summary>
    /// Minimal VM row for settlement output (does not depend on external DTOs).
    /// Extend/replace with real DTO when sales/settlement services are introduced.
    /// </summary>
    internal sealed class SettlementLineVm
    {
        public string CustomerName { get; set; } = string.Empty;
        public string ItemName { get; set; } = string.Empty;
        public DateTime SaleDate { get; set; } = DateTime.MinValue;
        public decimal ItemPrice { get; set; }
        public decimal CommissionPercent { get; set; } = 10m;

        public decimal CommissionAmount => Math.Round(ItemPrice * (CommissionPercent / 100m), 2);
        public decimal AmountToPay => Math.Round(ItemPrice - CommissionAmount, 2);
    }
}
