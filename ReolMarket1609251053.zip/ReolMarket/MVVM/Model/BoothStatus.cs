﻿namespace ReolMarket.MVVM.Model
{
    internal enum BoothStatus : byte
    {
        Ledig = 0,
        Optaget = 1,
        Opsagt = 2,
        Reserveret = 3
    }
}
