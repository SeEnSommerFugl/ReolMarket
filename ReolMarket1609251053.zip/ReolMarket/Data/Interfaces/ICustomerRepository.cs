﻿namespace ReolMarket.Data.Interfaces
{
    internal interface ICustomerRepository
    {
    }
}
