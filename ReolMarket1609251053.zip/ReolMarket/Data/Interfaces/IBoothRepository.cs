﻿namespace ReolMarket.Data.Interfaces
{
    internal interface IBoothRepository
    {

    }
}
