﻿namespace ReolMarket.Data.Interfaces
{
    internal interface IItemRepository
    {
    }
}
