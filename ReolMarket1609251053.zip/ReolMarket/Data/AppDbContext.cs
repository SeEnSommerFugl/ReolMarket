﻿namespace ReolMarket.Data
{
    internal class AppDbContext
    {

    }
}
