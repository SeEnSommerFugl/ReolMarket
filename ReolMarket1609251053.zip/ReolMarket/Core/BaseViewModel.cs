﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;

namespace ReolMarket.Core
{
    /// <summary>
    /// Base class for all ViewModels, providing property change notification,
    /// validation plumbing, busy-state handling, and a standard async load pattern.
    /// </summary>
    public abstract class BaseViewModel : INotifyPropertyChanged, INotifyDataErrorInfo, IDisposable
    {
        private string _title = string.Empty;
        private bool _isBusy;
        private string? _busyText;
        private readonly Dictionary<string, List<string>> _errors = new();
        private CancellationTokenSource? _loadCts;

        /// <summary>
        /// Raised when a property value changes (INotifyPropertyChanged).
        /// </summary>
        public event PropertyChangedEventHandler? PropertyChanged;

        /// <summary>
        /// Gets or sets the title for this ViewModel (useful for window/page headers).
        /// </summary>
        public string Title
        {
            get => _title;
            set => SetProperty(ref _title, value);
        }

        /// <summary>
        /// Indicates whether the ViewModel is currently performing a long-running operation.
        /// </summary>
        public bool IsBusy
        {
            get => _isBusy;
            protected set => SetProperty(ref _isBusy, value);
        }

        /// <summary>
        /// Optional text shown while the ViewModel is busy (e.g., “Loading booths…”).
        /// </summary>
        public string? BusyText
        {
            get => _busyText;
            protected set => SetProperty(ref _busyText, value);
        }

        /// <summary>
        /// Sets a backing field and raises PropertyChanged only when the value actually changes.
        /// </summary>
        protected bool SetProperty<T>(ref T field, T value, [CallerMemberName] string? propertyName = null)
        {
            if (EqualityComparer<T>.Default.Equals(field, value))
                return false;

            field = value;
            OnPropertyChanged(propertyName);
            return true;
        }

        /// <summary>
        /// Raises the PropertyChanged event for the provided property name.
        /// </summary>
        protected void OnPropertyChanged([CallerMemberName] string? propertyName = null) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));

        // ------------ Async Load pattern ------------

        /// <summary>
        /// Cancels any ongoing load operation (if present).
        /// </summary>
        protected void CancelLoad()
        {
            _loadCts?.Cancel();
            _loadCts?.Dispose();
            _loadCts = null;
        }

        /// <summary>
        /// Starts (re)loading the ViewModel state asynchronously.
        /// Cancels any existing load, toggles IsBusy, and calls OnLoadAsync.
        /// </summary>
        public async Task LoadAsync(CancellationToken cancellationToken = default)
        {
            CancelLoad();
            _loadCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            var ct = _loadCts.Token;

            try
            {
                IsBusy = true;
                BusyText = BusyText ?? "Loading…";
                await OnLoadAsync(ct).ConfigureAwait(false);
            }
            finally
            {
                IsBusy = false;
                BusyText = null;
            }
        }

        /// <summary>
        /// Override in derived ViewModels to implement the actual load logic.
        /// </summary>
        protected virtual Task OnLoadAsync(CancellationToken ct) => Task.CompletedTask;

        /// <summary>
        /// Executes the provided async action while handling IsBusy/BusyText
        /// and honoring cancellation. Use this for button commands that do async work.
        /// </summary>
        protected async Task RunBusyAsync(Func<CancellationToken, Task> action, string? busyText = null, CancellationToken ct = default)
        {
            var linked = CancellationTokenSource.CreateLinkedTokenSource(ct);
            try
            {
                IsBusy = true;
                if (!string.IsNullOrWhiteSpace(busyText))
                    BusyText = busyText;

                await action(linked.Token).ConfigureAwait(false);
            }
            finally
            {
                IsBusy = false;
                BusyText = null;
                linked.Dispose();
            }
        }

        /// <summary>
        /// Executes the provided synchronous action while handling IsBusy/BusyText.
        /// Use this for commands that call synchronous repositories.
        /// </summary>
        protected void RunBusy(Action action, string? busyText = null)
        {
            try
            {
                IsBusy = true;
                if (!string.IsNullOrWhiteSpace(busyText))
                    BusyText = busyText;

                action();
            }
            finally
            {
                IsBusy = false;
                BusyText = null;
            }
        }

        // ------------ Validation (INotifyDataErrorInfo) ------------

        /// <summary>
        /// True if the ViewModel has any validation errors.
        /// </summary>
        public bool HasErrors => _errors.Count > 0;

        /// <summary>
        /// Raised when validation errors change for a property.
        /// </summary>
        public event EventHandler<DataErrorsChangedEventArgs>? ErrorsChanged;

        /// <summary>
        /// Returns the validation errors for a given property.
        /// </summary>
        public IEnumerable GetErrors(string? propertyName)
        {
            if (string.IsNullOrEmpty(propertyName))
                return Array.Empty<string>();

            return _errors.TryGetValue(propertyName, out var list) ? (IEnumerable)list : Array.Empty<string>();
        }

        /// <summary>
        /// Adds a validation error for the specified property.
        /// </summary>
        protected void AddError(string propertyName, string error)
        {
            if (!_errors.TryGetValue(propertyName, out var list))
            {
                list = new List<string>();
                _errors[propertyName] = list;
            }

            if (!list.Contains(error))
            {
                list.Add(error);
                RaiseErrorsChanged(propertyName);
            }
        }

        /// <summary>
        /// Clears all validation errors for the specified property.
        /// </summary>
        protected void ClearErrors(string propertyName)
        {
            if (_errors.Remove(propertyName))
            {
                RaiseErrorsChanged(propertyName);
            }
        }

        /// <summary>
        /// Raises ErrorsChanged for the specified property.
        /// </summary>
        protected void RaiseErrorsChanged(string propertyName) =>
            ErrorsChanged?.Invoke(this, new DataErrorsChangedEventArgs(propertyName));

        /// <summary>
        /// Re-run validation for all relevant properties.
        /// Override to implement ViewModel-specific validation rules.
        /// Call this from setters to keep errors current.
        /// </summary>
        protected virtual void Validate() { }

        // ------------ Disposal ------------

        /// <summary>
        /// Disposes resources held by the ViewModel (e.g., cancellation tokens).
        /// </summary>
        public void Dispose()
        {
            CancelLoad();
            OnDispose();
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Override for additional clean-up in derived classes.
        /// </summary>
        protected virtual void OnDispose() { }
    }
}
